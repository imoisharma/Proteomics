# Load libraries
library(ChIPseeker)
library(TxDb.Scerevisiae.UCSC.sacCer3.sgdGene)
library(clusterProfiler)
library(annotables)
library(org.Sc.sgd.db)
library(GenomicRanges)
#library(diffloop)


samplefiles <-list.files("/srv/home/yagr0003/chipseeker/",pattern= ".bed", full.names=T)
samplefiles <- as.list(samplefiles)
print(samplefiles)

peak <- readPeakFile(samplefiles[[2]])

#names(samplefiles) <-c("YEPD", "KCI")
txdb <- TxDb.Scerevisiae.UCSC.sacCer3.sgdGene
#covplot(peak,weightCol="V5")
#peakAnno <- annotatePeak(samplefiles[[2]],TxDb=txdb,tssRegion=c(-3000,3000),annoDb='org.Sc.sgd.db',verbose=TRUE)
#print(peakAnno)


library(tidyverse)
mapping <- read_tsv("/srv/home/yagr0003/chipseeker/SRR-Hog1IP_mockIP_KCI_peaks_chr.bed",col_names=FALSE) %>%
    select(X2,X1) %>%
    distinct() %>%
    deframe()

# Mapping is a named character vector
mapping

peak2 <- peak
#seqlevels(peak2) <- mapping[seqlevels(peak2)]

peakAnno <- annotatePeak(peak2,TxDb=txdb,tssRegion=c(-3000,3000),annoDb='org.Sc.sgd.db',verbose=TRUE)

output_df <-  as.data.frame(peakAnno)

output_df %>% head(10)

write.table(output_df,"output_kci")

plotAnnoBar(peakAnno)

plotDistToTSS(peakAnno, title="Distribution of transcription factor-binding loci \n relative to TSS")

#?annotatePeak

