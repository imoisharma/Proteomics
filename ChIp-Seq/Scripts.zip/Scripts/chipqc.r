library(DiffBind)
library(tidyverse)
##Reading in Peaksets
samples <- read.csv('/srv/home/yagr0003/chipseeker/samplesheet_chr.csv')
dbObj <- dba(sampleSheet=samples)
dbObj
##Affinity binding matrix
dbObj <- dba.count(dbObj, bUseSummarizeOverlaps=TRUE)
##Exploratory data analysis
dba.plotPCA(dbObj, attributes=DBA_FACTOR, label=DBA_ID)
plot(dbObj)
